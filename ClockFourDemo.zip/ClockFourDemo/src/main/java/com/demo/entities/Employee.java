package com.demo.entities;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Setter;

@XmlRootElement(name = "Employee")
public class Employee {
	@Setter
	String firstName;
	@Setter
	String lastName;
	@Setter
	String dateOfBirth;

	@XmlElement
	public String getLastName() {
		return lastName;
	}
	
	@XmlElement
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	
	@XmlElement
	public String getFirstName() {
		return firstName;
	}
}
