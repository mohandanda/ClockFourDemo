package com.demo.entities;

import lombok.Getter;
import lombok.Setter;

public class ErrorResponse {
	@Setter
	@Getter
	private String errorCode;
	
	@Setter
	@Getter
	private String errorMessage;
}
