package com.demo.entities;

import lombok.Getter;
import lombok.Setter;

public class ImageAttribute {

	@Setter
	@Getter
	String name;
	
	@Setter
	@Getter
	Long size;

}
