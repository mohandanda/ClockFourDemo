package com.demo.utilities;

public class ErrorCode {
 public static String MALFORMED_REQUEST = "91001";
 public static String JSON_PARSE_FAILURE = "92002";
 public static String JSON_INPUT_NULL_ERROR = "93003";
 
}
